# Unified Chat Android prototype

Proof-of-concept for a unified inbox using Android notification access and notification RemoteInput replies.

## Test
1. Open the project in Android Studio (current stable).
2. Let Gradle sync, connect an Android phone, and Run the app.
3. Tap **Giv adgang til beskednotifikationer** and enable Unified Chat.
4. Have someone send a Messenger or Instagram message while notifications are enabled.
5. Open Unified Chat. The notification should appear in the inbox.
6. Open it. If the source notification exposes Android free-form RemoteInput, type a reply and press Send.
7. Verify on the sender's phone that the reply arrived.

## Current scope
- Captures title/text/source/time from notifications.
- Recognizes Messenger, Instagram, WhatsApp, Telegram, Signal and Discord package names.
- Detects free-form RemoteInput reply actions.
- Sends replies through the original app's PendingIntent.
- Data is currently in memory only and disappears when the process is killed.

## Next engineering milestones
- Persist normalized conversations/messages locally (Room/SQLite).
- Robust MessagingStyle parsing (message arrays, groups, sender metadata).
- Deduplication and conversation identity mapping.
- SMS/MMS/default-role connector.
- Speech-to-text composer.
- Deep-link fallback when direct reply is unavailable.
- Gmail/Outlook connectors and on-device search/AI layer.

## Important limitation
Notification access is not a substitute for an official Messenger/Instagram API. It only exposes what Android and the source app put into notifications, and direct sending only works when that notification exposes a compatible reply action.
