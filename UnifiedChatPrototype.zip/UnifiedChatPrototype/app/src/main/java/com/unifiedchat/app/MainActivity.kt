package com.unifiedchat.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.unifiedchat.app.data.UnifiedMessage
import com.unifiedchat.app.data.MessageStore
import com.unifiedchat.app.notifications.UniversalNotificationListener
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { UnifiedChatApp { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } } }
    }
}

@Composable
fun UnifiedChatApp(openAccess: () -> Unit) {
    val messages by MessageStore.messages.collectAsState()
    var selected by remember { mutableStateOf<UnifiedMessage?>(null) }
    Surface(Modifier.fillMaxSize()) {
        if (selected == null) Inbox(messages, openAccess) { selected = it }
        else Conversation(selected!!, { selected = null })
    }
}

@Composable
private fun Inbox(messages: List<UnifiedMessage>, openAccess: () -> Unit, onOpen: (UnifiedMessage) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(22.dp))
        Text("Unified", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Alle dine samtaler ét sted", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        Button(onClick = openAccess, modifier = Modifier.fillMaxWidth()) { Text("Giv adgang til beskednotifikationer") }
        Spacer(Modifier.height(14.dp))
        if (messages.isEmpty()) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Klar til første test", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Aktivér adgangen ovenfor. Få derefter nogen til at sende dig en Messenger- eller Instagram-besked. Den skal dukke op her.")
                }
            }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.key }) { m ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(m) }, shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(m.sender, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(8.dp)); AssistChip(onClick = {}, label = { Text(m.source) })
                            }
                            Text(m.text, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.timestamp)), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun Conversation(message: UnifiedMessage, back: () -> Unit) {
    var reply by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        TextButton(onClick = back) { Text("← Tilbage") }
        Text(message.sender, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(message.source, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(28.dp))
        Card(shape = RoundedCornerShape(22.dp)) { Text(message.text, Modifier.padding(18.dp)) }
        Spacer(Modifier.weight(1f))
        if (message.reply == null) Text("Denne besked tilbyder ikke direkte svar via Android-notifikationen.", color = MaterialTheme.colorScheme.error)
        status?.let { Text(it) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(reply, { reply = it }, Modifier.weight(1f), placeholder = { Text("Skriv svar…") })
            Spacer(Modifier.width(8.dp))
            Button(enabled = reply.isNotBlank() && message.reply != null, onClick = {
                status = UniversalNotificationListener.sendReply(message, reply).fold({ reply = ""; "Sendt via ${message.source}" }, { "Kunne ikke sende: ${it.message}" })
            }) { Text("Send") }
        }
        Spacer(Modifier.height(12.dp))
    }
}
