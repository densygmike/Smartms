package com.unifiedchat.app.notifications

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.unifiedchat.app.data.MessageStore
import com.unifiedchat.app.data.ReplyHandle
import com.unifiedchat.app.data.UnifiedMessage

class UniversalNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val extras = n.extras ?: return
        val sender = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: appLabel(sbn.packageName)
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: return
        if (text.isBlank()) return

        val replyAction = n.actions?.firstOrNull { action ->
            action.remoteInputs?.any { it.allowFreeFormInput } == true
        }
        val reply = replyAction?.remoteInputs?.let { ReplyHandle(replyAction.actionIntent, it) }

        MessageStore.upsert(
            UnifiedMessage(
                key = sbn.key,
                sender = sender,
                text = text,
                source = sourceName(sbn.packageName),
                packageName = sbn.packageName,
                timestamp = sbn.postTime,
                reply = reply
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Keep the captured message in the prototype inbox; real persistence comes next.
    }

    private fun appLabel(pkg: String): String = try {
        val info = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(info).toString()
    } catch (_: Exception) { pkg }

    private fun sourceName(pkg: String): String = when (pkg) {
        "com.facebook.orca" -> "Messenger"
        "com.instagram.android" -> "Instagram"
        "com.whatsapp" -> "WhatsApp"
        "org.telegram.messenger" -> "Telegram"
        "org.thoughtcrime.securesms" -> "Signal"
        "com.discord" -> "Discord"
        else -> appLabel(pkg)
    }

    companion object {
        fun sendReply(message: UnifiedMessage, text: String): Result<Unit> = runCatching {
            val handle = requireNotNull(message.reply) { "Denne notifikation har ingen reply-action" }
            val intent = Intent()
            val results = Bundle()
            handle.remoteInputs.forEach { results.putCharSequence(it.resultKey, text) }
            RemoteInput.addResultsToIntent(handle.remoteInputs, intent, results)
            handle.pendingIntent.send(null, 0, intent)
        }
    }
}
