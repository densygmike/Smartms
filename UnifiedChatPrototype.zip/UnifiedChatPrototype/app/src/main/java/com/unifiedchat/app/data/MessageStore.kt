package com.unifiedchat.app.data

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UnifiedMessage(
    val key: String,
    val sender: String,
    val text: String,
    val source: String,
    val packageName: String,
    val timestamp: Long,
    val reply: ReplyHandle? = null
)

data class ReplyHandle(
    val pendingIntent: PendingIntent,
    val remoteInputs: Array<RemoteInput>
)

object MessageStore {
    private val _messages = MutableStateFlow<List<UnifiedMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    fun upsert(message: UnifiedMessage) {
        _messages.value = (listOf(message) + _messages.value.filterNot { it.key == message.key }).take(200)
    }

    fun remove(key: String) { _messages.value = _messages.value.filterNot { it.key == key } }
}
